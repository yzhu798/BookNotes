#include "Blue.h"


Blue::Blue()
{
}

void Blue::fill()
{
	cout << "Inside Blue::fill() method." << endl;
}

Blue::~Blue()
{
}
