#include "Color.h"


Color::Color()
{
}


Color::~Color()
{
}
