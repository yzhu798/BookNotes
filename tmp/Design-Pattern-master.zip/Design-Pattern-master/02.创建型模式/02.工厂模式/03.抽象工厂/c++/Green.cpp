#include "Green.h"


Green::Green()
{
}

void Green::fill()
{
	cout << "Inside Green::fill() method." << endl;

}
Green::~Green()
{
}
