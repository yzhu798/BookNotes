#include "Red.h"


Red::Red()
{
}

void Red::fill()
{
	cout << "Inside Red::fill() method." << endl;
}

Red::~Red()
{
}
