#pragma once
class Color
{
public:
	Color();
	virtual void fill() = 0;
	virtual ~Color();
};

