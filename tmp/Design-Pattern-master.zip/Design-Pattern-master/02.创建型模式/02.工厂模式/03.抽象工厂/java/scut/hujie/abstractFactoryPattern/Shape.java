package scut.hujie.abstractFactoryPattern;

public interface Shape {
	void draw();
}
