package scut.hujie.abstractFactoryPattern;

public interface Color {
	void fill();
}
