#include "Circle.h"


Circle::Circle()
{
}

void Circle::draw()
{
	cout << "Inside Circle::draw() method." << endl;
}

Circle::~Circle()
{
}
