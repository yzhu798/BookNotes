#pragma once
class Shape
{
public:
	Shape();
	virtual void draw() = 0;
	virtual ~Shape();
};

