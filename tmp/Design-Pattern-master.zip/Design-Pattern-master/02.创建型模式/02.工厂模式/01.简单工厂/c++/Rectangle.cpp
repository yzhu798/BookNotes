#include "Rectangle.h"


Rectangle::Rectangle()
{
}

void Rectangle::draw()
{
	cout << "Inside Rectangle::draw() method." << endl;
}

Rectangle::~Rectangle()
{
}
