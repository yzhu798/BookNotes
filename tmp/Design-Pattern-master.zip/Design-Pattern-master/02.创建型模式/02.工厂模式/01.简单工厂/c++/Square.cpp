#include "Square.h"


Square::Square()
{
}

void Square::draw()
{
	cout << "Inside Square::draw() method." << endl;
}

Square::~Square()
{
}
