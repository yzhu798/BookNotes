package scut.hujie.factoryMetodPattern;

public interface Shape {
	void draw();
}
