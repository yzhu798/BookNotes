package scut.hujie.observerPattern2;

public abstract class Observer {
	public abstract void update(String msg);
}
