#include "Observer.h"
#include <string>
using namespace std;

Observer::Observer()
{
}


Observer::~Observer()
{
}
