#include "S_Observer.h"


S_Observer::S_Observer()
{
}

void S_Observer::update(string msg)
{
	cout << "S_Observer: " << msg << endl;
}

S_Observer::~S_Observer()
{
}
