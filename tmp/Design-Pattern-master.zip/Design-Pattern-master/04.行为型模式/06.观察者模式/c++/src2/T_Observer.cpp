#include "T_Observer.h"


T_Observer::T_Observer()
{
}

void T_Observer::update(string msg)
{
	cout << "T_Observer: " << msg << endl;
}

T_Observer::~T_Observer()
{
}
