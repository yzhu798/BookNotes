#include "F_Observer.h"


F_Observer::F_Observer()
{
}

void F_Observer::update(string msg)
{
	cout << "F_Observer: " << msg << endl;
}

F_Observer::~F_Observer()
{
}
