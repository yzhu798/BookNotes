#include "State.h"
#include "Context.h"

State::State()
{
}


State::~State()
{
}
