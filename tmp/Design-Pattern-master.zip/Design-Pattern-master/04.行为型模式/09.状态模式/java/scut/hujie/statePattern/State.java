package scut.hujie.statePattern;

public interface State {
	public void doAction(Context context);
	public String toString();
}
