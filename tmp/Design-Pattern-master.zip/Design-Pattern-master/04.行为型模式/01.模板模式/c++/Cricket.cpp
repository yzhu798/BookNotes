#include "Cricket.h"

Cricket::Cricket()
{
}

void Cricket::initialize()
{
	cout << "Cricket Game Initialized! Start playing." << endl;
}

void Cricket::startPlay()
{
	cout << "Cricket Game Started. Enjoy the game!" << endl;
}

void Cricket::endPlay()
{
	cout << "Cricket Game Finished!" << endl;
}

Cricket::~Cricket()
{
}
