#include "Football.h"


Football::Football()
{
}

void Football::initialize()
{
	cout << "Football Game Initialized! Start playing." << endl;
}

void Football::startPlay()
{
	cout << "Football Game Started. Enjoy the game!" << endl;
}

void Football::endPlay()
{
	cout << "Football Game Finished!" << endl;
}

Football::~Football()
{
}
