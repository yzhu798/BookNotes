package scut.hujie.commandPattern;

public interface Order {
	void execute();
}
