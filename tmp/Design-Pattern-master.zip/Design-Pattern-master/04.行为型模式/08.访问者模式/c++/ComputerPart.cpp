#include "ComputerPart.h"
#include "ComputerPartVisitor.h"

ComputerPart::ComputerPart()
{
}


ComputerPart::~ComputerPart()
{
}
