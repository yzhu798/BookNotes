#include "ComputerPartVisitor.h"


ComputerPartVisitor::ComputerPartVisitor()
{
}


ComputerPartVisitor::~ComputerPartVisitor()
{
}
