#include "OperationAdd.h"


OperationAdd::OperationAdd()
{
}

int OperationAdd::doOperation(int num1, int num2)
{
	return num1 + num2;
}

OperationAdd::~OperationAdd()
{
}
