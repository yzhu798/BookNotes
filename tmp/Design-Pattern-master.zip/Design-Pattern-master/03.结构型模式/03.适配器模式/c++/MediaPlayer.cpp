#include "MediaPlayer.h"


MediaPlayer::MediaPlayer()
{
}


MediaPlayer::~MediaPlayer()
{
}
