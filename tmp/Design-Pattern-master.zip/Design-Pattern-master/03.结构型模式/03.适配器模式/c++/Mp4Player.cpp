#include "Mp4Player.h"


Mp4Player::Mp4Player()
{
}

void Mp4Player::playVlc(string fileName)
{
	
}

void Mp4Player::playMp4(string fileName)
{
	cout << "Playing mp4 file. Name: " << fileName << endl;
}

Mp4Player::~Mp4Player()
{
}
