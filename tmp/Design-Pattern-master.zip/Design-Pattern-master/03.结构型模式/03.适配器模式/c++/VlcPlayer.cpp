#include "VlcPlayer.h"

VlcPlayer::VlcPlayer()
{
}

void VlcPlayer::playVlc(string fileName)
{
	cout << "Playing vlc file. Name: " << fileName << endl;
}

void VlcPlayer::playMp4(string fileName)
{

}

VlcPlayer::~VlcPlayer()
{
}
