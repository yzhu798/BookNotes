#include "AdvancedMediaPlayer.h"


AdvancedMediaPlayer::AdvancedMediaPlayer()
{
}


AdvancedMediaPlayer::~AdvancedMediaPlayer()
{
}
