package scut.hujie.proxyPattern;

public interface Image {
	void display();
}
