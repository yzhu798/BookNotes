#pragma once
class Image
{
public:
	Image();
	virtual void display() = 0;
	virtual ~Image();
};

