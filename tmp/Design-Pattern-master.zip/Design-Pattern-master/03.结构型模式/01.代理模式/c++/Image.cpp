#include "Image.h"


Image::Image()
{
}


Image::~Image()
{
}
