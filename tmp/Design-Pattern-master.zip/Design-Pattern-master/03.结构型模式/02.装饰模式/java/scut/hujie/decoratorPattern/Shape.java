package scut.hujie.decoratorPattern;

public interface Shape {
	void draw();
}
