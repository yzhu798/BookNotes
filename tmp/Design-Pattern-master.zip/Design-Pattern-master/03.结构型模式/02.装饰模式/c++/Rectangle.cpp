#include "Rectangle.h"


Rectangle::Rectangle()
{
}

void Rectangle::draw()
{
	cout << "Shape: Rectangle" << endl;
}

Rectangle::~Rectangle()
{
}
