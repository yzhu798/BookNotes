#include "Circle.h"


Circle::Circle()
{
}

void Circle::draw()
{
	cout << "Shape: Circle" << endl;
}

Circle::~Circle()
{
}
