#include "RedCircle.h"


RedCircle::RedCircle()
{
}

void RedCircle::drawCircle(int radius, int x, int y)
{
	cout << "Drawing Circle[ color: red, radius: " << radius << ", x: " << x << ", " << y << "]" << endl;
}

RedCircle::~RedCircle()
{
}
