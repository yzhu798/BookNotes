#include "GreenCircle.h"


GreenCircle::GreenCircle()
{
}

void GreenCircle::drawCircle(int radius, int x, int y)
{
	cout << "Drawing Circle[ color: green, radius: " << radius << ", x: " << x << ", " << y << "]" << endl;
}

GreenCircle::~GreenCircle()
{
}
