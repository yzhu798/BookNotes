#include "DrawAPI.h"


DrawAPI::DrawAPI()
{
}


DrawAPI::~DrawAPI()
{
}
