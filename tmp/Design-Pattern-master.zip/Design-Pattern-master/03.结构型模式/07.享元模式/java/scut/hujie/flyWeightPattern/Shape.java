package scut.hujie.flyWeightPattern;

public interface Shape {
	void draw();
}
