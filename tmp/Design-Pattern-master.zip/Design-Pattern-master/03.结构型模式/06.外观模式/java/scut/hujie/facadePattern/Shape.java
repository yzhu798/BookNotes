package scut.hujie.facadePattern;

public interface Shape {
	void draw();
}
