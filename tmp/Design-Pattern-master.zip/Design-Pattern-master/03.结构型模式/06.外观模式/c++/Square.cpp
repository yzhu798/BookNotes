#include "Square.h"


Square::Square()
{
}

void Square::draw()
{
	cout << "Square::draw()" << endl;
}

Square::~Square()
{
}
