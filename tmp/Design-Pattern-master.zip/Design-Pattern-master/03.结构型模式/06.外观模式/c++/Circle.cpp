#include "Circle.h"


Circle::Circle()
{
}

void Circle::draw()
{
	cout << "Circle::draw()" << endl;
}

Circle::~Circle()
{
}
