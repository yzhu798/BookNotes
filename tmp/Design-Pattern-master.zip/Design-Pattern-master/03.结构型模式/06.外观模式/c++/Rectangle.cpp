#include "Rectangle.h"


Rectangle::Rectangle()
{
}

void Rectangle::draw()
{
	cout << "Rectangle::draw()" << endl;
}

Rectangle::~Rectangle()
{
}
